# Integrantes:
# Yolanda Araya
# Jimena Aliaga
# Rolando Piñones
# Jonathan Castro
# Alejandro Cofré

require "./class/producto.rb"
require "./class/marca.rb"
require "./class/categoria.rb"

def mostrarMenu
    puts
    puts '--------------------------------------------------'
    puts '|  Bienvenido al Identificador de precios 3b\'s  |'
    puts '--------------------------------------------------'
    puts
    puts
    puts '-------- Catálogo de Productos -------------------'
    puts
    puts
    puts 'Qué acción quieres realizar:'
    puts
    puts '1. Alta de marca'
    puts '2. Alta de categoria'
    puts '3. Alta de producto'
    puts '4. Buscar Producto por clave'
    puts '5. Buscar Producto por nombre'
    puts '6. Registrar stock inicial'
    puts '7. Registrar movimiento de stock'
    puts '8. Realizar cierre de stock'
    puts '0. Salir'
    puts
    puts 'Qué acción quieres realizar:'
    print '> '
    opcion = gets.chomp.to_i
    return opcion
end

def menu01() # '1. Alta de marca'
  a = Marca.new("","")
  puts "Cuántas marcas quieres ingresar?"
  numero = gets.chomp.to_i

  numero.times do
    puts "Ingrese nueva marca?"
    newMarca = gets.chomp
    a.altaMarca(newMarca)
  end
    
end

def menu02() # '2. Alta de categoria'
  a = Categoria.new("","")
  puts "Cuántas categorias quieres ingresar?"
  numero = gets.chomp.to_i

  numero.times do
    puts "Ingrese nueva categoria?"
    newCateg = gets.chomp
    a.altaCategoria(newCateg)
  end
    
end

def menu03() # '3. Alta de producto'
  a = Producto.new("","","","","","","","","","","","","","","")
  prod = a.altaProducto()
  $maestroProductos.push(prod)

  print $maestroProductos

end

def menu04() # '4. Buscar Producto por clave'
    puts "Ingrese el código a buscar:"
    codigo = gets.chomp
    a = Producto.new("","","","","","","","","","","","","","","")
    resultado = a.buscarXClave($maestroProductos, codigo)
    if resultado.class == 0.class
      puts "Codigo no existe"
    else
      puts resultado.to_print
    end
    puts
    puts "Pulse <ENTER> para continuar"
    gets.chomp
end

def menu05() # '5. Buscar Producto por nombre'
    puts "Ingrese el nombre de producto a buscar:"
    codigo = gets.chomp
    a = Producto.new("","","","","","","","","","","","","","","")
    resultado = a.buscarXNombre($maestroProductos, codigo)
    if resultado.class == 0.class
      puts "Codigo no existe"
    else
      puts resultado.to_print
    end
    puts
    puts "Pulse <ENTER> para continuar"
    gets.chomp
    
end

def menu06() # '6. Registrar stock inicial'
  puts "Registrando stock inicial del año..."

  File.open("./db/inventario_final.txt","w") do |file|
    for prod in $maestroProductos do
      puts "Stock para #{prod.nombre} :"
      n = gets.chomp.to_i
      file.write("#{prod.clave},#{n},0,0,#{n}\n")
    end
  end
  puts "Stock inicial registrado. Pulse <ENTER> para continuar..."
  gets.chomp
end

def menu07() # '7. Registrar movimiento de stock'
    puts "Bienvenido al registro de movimiento de stock"
    puts
    seguir = "S"
    loop do
      break if seguir != "S"
      puts "Qué producto quiere registrar? (CLAVE)"
      clave = gets.chomp
      a = Producto.new("","","","","","","","","","","","","","","")
      prod = a.buscarXClave($maestroProductos,clave)
      if prod.class == 0.class
        puts "Clave de Producto no encontrada. Pulse <ENTER> para continuar"
        gets.chomp
      else
        puts "Cuantas unidades son las del movimiento (+ si agrega, - si quita)"
        cantidad = gets.chomp.to_i
        if cantidad > 0
          movimiento = "i"
        else
          movimiento = "s"
        end
        t = Time.now
        fecha = "#{t.year}/#{t.month}/#{t.day}"
        hora = "#{t.hour}:#{t.min}"
        File.open("./db/transacciones_producto.txt","a") do |file|
          file.write("#{clave},#{fecha},#{hora},#{movimiento},#{cantidad.abs()}\n")
        end
      end
      puts "Quiere agregar otro movimiento? [S/N]"
      seguir = gets.chomp.upcase
    end
end

def menu08() # '8. Realizar cierre de stock'
  puts "Bienvenido al cierre de stock"
  puts
  puts "Está seguro que quiere cerrar el stock? [S/N]"
  respuesta = gets.chomp
  if respuesta.upcase == "S"
    require "csv"
    inventario_inicial = CSV.read("./db/inventario_final.txt")
    movimientos = CSV.read("./db/transacciones_producto.txt")
    for mov in movimientos do
      for prod in inventario_inicial do
        if mov[0] == prod[0]
          if mov[3] == 'i'
            prod[2] = prod[2].to_i + mov[4].to_i
          elsif mov[3] == 's'
            prod[3] = prod[3].to_i + mov[4].to_i
          end
        end
      end
    end

    puts "Calculo hecho"
    File.open("./db/inventario_final.txt","w") do |file|
      for prod in inventario_inicial do
        final = prod[1].to_i+prod[2].to_i-prod[3].to_i
        file.write("#{prod[0]},#{prod[1]},#{prod[2]},#{prod[3]},#{final}\n")
      end
    end

  else
    puts "Cierre de stock cancelado. Presione <ENTER> para continuar..."
    gets.chomp
  end
end


def menu00
    # '0. Salir'
    puts 'Saliendo del programa...'
end

def inicializaPrograma
     require 'csv'
     content = CSV.read("./db/catalogo_marca.txt")
     for linea in content do
        marca = Marca.new(linea[0],linea[1])
        $maestroMarcas.push(marca)
     end
     content =  CSV.read("./db/catalogo_categorias.txt")
     for linea in content do
        categoria = Categoria.new(linea[0],linea[1])
        $maestroCategorias.push(categoria)
     end
     content =  CSV.read("./db/maestro_productos.txt")
     for linea in content do
        print linea
        puts
        producto = Producto.new(linea[0],linea[1],linea[2],linea[3],linea[4],linea[5],linea[6],linea[7],linea[8],linea[9],linea[10],linea[11],linea[12],linea[13],linea[14])
        $maestroProductos.push(producto)
        puts "clave de producto: ", producto.clave
     end

end

# Aquí comienza el principal
$maestroMarcas = []
$maestroCategorias = []
$maestroProductos = []
inicializaPrograma
# print $maestroMarcas
# puts
# print $maestroCategorias
# puts
# print $maestroProductos
# puts

# print $maestroMarcas
# puts
# puts $maestroMarcas[0]
# puts $maestroMarcas[0].class
# puts
# print $maestroCategorias
# puts
# puts $maestroCategorias[0]
# puts $maestroCategorias[0].class
# puts
print $maestroProductos
puts
puts $maestroProductos[0]
puts $maestroProductos[0].class
puts $maestroProductos[0].to_print
puts

menu = 10
loop do
    break if menu == 0
    menu = mostrarMenu()
    if menu == 1
      menu01()
    elsif menu == 2
      menu02()
    elsif menu == 3
      menu03()
    elsif menu == 4
    # '4. Buscar Producto por clave'    
        menu04()
    elsif menu == 5
    # '5. Buscar Producto por nombre'
        menu05()
    elsif menu == 6
      menu06()
    elsif menu == 7
      menu07()
    elsif menu == 8
      menu08()
    elsif menu == 0
      menu00()
    else
      puts 'Opción no aceptada'
    end 
  end
  
  puts "Gracias por participar..."
  
