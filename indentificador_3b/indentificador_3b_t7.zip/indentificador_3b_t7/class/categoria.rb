class Categoria < Producto
    attr_accessor :id,:nombre
    def initialize (numero, categoria)
        @id = numero
        @nombre = categoria
    end

    def buscarXID(idCateg)
        flag = 0
        for cat in $maestroCategorias do
           if cat.id == idCateg
                return cat
           end
        end
        return flag
    end

    def altaCategoria(categNueva)
        a = Categoria.new("","")
        idUltimo = $maestroCategorias[-1].id.to_i
        categ = a.buscarXNombre($maestroCategorias,categNueva)
        if categ.class == 0.class
            a.nombre = categNueva
            a.id = idUltimo + 1
            File.open("./db/catalogo_categorias.txt", "a") do |file|
                file.write(a.to_csv)
            end
            $maestroCategorias.push(a)
        else
            puts "La categoria #{categNueva} ya existe"
        end
    end

    def to_csv
        return "#{id},\"#{nombre}\"\n"
    end

end