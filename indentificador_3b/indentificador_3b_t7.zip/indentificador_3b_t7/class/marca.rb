class Marca < Producto
    attr_accessor :id,:nombre
    def initialize (numero, marca)
        @id = numero
        @nombre = marca
    end

    def altaMarca(marcaNueva)
        a = Marca.new("","")
        idUltimo = $maestroMarcas[-1].id.to_i
        marca = a.buscarXNombre($maestroMarcas,marcaNueva)
        if marca.class == 0.class
            a.nombre = marcaNueva
            a.id = idUltimo + 1
            File.open("./db/catalogo_marca.txt", "a") do |file|
                file.write(a.to_csv)
            end
            $maestroMarcas.push(a)
        else
            puts "La marca #{marcaNueva} ya existe"
        end
    end

    def to_csv
        return "#{id},\"#{nombre}\"\n"
    end
end