require 'csv'

class Producto
# Los atributos comienzan aquí    
    attr_accessor :clave,:ean13,:nombre,:idMarca,:modelo,:idCategoria,:subCategoria,:uniCantidad,:cantidad,:uniContenido,:contenido,:precioNeto,:pDescuento,:netoConDescuento,:precioIVA


# Los métodos comienzan acá
    def initialize (clave,ean13,nombre,idMarca,modelo,idCategoria,subCategoria,uniCantidad,cantidad,uniContenido,contenido,precioNeto,pDescuento,netoConDescuento,precioIVA)
        @clave = clave
        @ean13 = ean13
        @nombre = nombre
        @idMarca = idMarca
        @modelo = modelo
        @idCategoria = idCategoria
        @subCategoria = subCategoria
        @uniCantidad = uniCantidad
        @cantidad = cantidad
        @uniContenido = uniContenido
        @contenido = contenido
        @precioNeto = precioNeto
        @pDescuento = pDescuento
        @netoConDescuento = netoConDescuento
        @precioIVA = precioIVA
    end

    def generaClave(ean13,idCategoria)
        numero = ean13.to_s
        a = Categoria.new("","")
        categoria = a.buscarXID(idCategoria)
        clave = numero[0..1] + categoria.nombre[0..2].upcase + '3BS'
        return clave
    end

    def descuentoProducto
        
    end

    def precioFinal
        precioIVA = netoConDescuento * 1.19
        # return precioIVA
    end

    def altaProducto
        puts 'Cuantos productos deseas ingresar?:'
        numero = gets.chomp.to_i
        
        numero.times do
            # Aquí empieza la consulta del producto
            puts '--- Ingresa la siguiente información del producto ---'
        
            puts 'Ingresa la ean(13)'
            ean13 = gets.chomp.to_i
        
            puts 'Ingresa nombre'
            nombre = gets.chomp
        
            puts 'Ingresa marca'
            marca = gets.chomp
            a = Marca.new("","")
            test = a.buscarXNombre($maestroMarcas,marca)
            if test.class == 0.class
                idMarca = a.altaMarca(marca)
            else
                idMarca = test.id    
            end
        
            puts 'Ingresa Modelo'
            modelo = gets.chomp

            puts 'Ingresa categoria'
            categoria = gets.chomp
            a = Categoria.new("","")
            test = a.buscarXNombre($maestroCategorias,categoria)
            if test.class == 0.class
                idCategoria = a.altaCategoria(categoria)
            else
                idCategoria = test.id
            end

            puts 'Ingresa Subcategoria'
            subCategoria = gets.chomp

            puts 'Ingresa Unidad'
            uniCantidad = gets.chomp
        
            puts 'Ingresa Cantidad'
            cantidad = gets.chomp.to_i
        
            puts 'Ingresa Unidad Contenido'
            uniContenido = gets.chomp
        
            puts 'Ingresa Contenido'
            contenido = gets.chomp
        
            puts 'Ingresa Precio Neto'
            precioNeto = gets.chomp.to_i
        
            puts 'Ingresa porcentaje de descuento (de 1 a 99)'
            pDescuento = gets.chomp.to_i

            clave = self.generaClave(ean13,idCategoria)
            netoConDescuento = precioNeto * (1-pDescuento/100)
            precioIVA = netoConDescuento * 1.19

            prod = Producto.new(clave,ean13,nombre,idMarca,modelo,idCategoria,subCategoria,uniCantidad,cantidad,uniContenido,contenido,precioNeto,pDescuento,netoConDescuento,precioIVA)

            File.open("./db/maestro_productos.txt", "a") do |file|
                file.write(prod.to_csv)
            end
            return prod
            # agregar el producto al array virtual de productos

        end
    end

    def inventarioInicial
        
    end

    def movimientoInventario
        
    end

    def inventarioFinal
        
    end

    def buscarXClave(array, codigo)
        flag = 0
        for prod in array do
            # puts "#{prod.clave}, #{codigo}"
           if prod.clave == codigo
                return prod
           end
        end
        return flag
    end

    def buscarXNombre(array, nombre)
        flag = 0
        for prod in array do
           if prod.nombre == nombre
                return prod
           end
        end
        return flag
    end

    def to_print
        return "clave: #{clave} - nombre: #{nombre} - unidad: #{uniCantidad} - Precio Neto: $ #{precioNeto} - Precio con Descuento = $ #{netoConDescuento} - Precio = $ #{precioIVA} - Marca : #{idMarca} - Categoria = #{idCategoria} \n"
    end

    def to_csv
        return "#{clave},#{ean13},#{nombre},#{idMarca},#{modelo},#{idCategoria},#{subCategoria},#{uniCantidad},#{cantidad},#{contenido},#{uniContenido},#{precioNeto},#{pDescuento},#{netoConDescuento},#{precioIVA} \n"
    end

end